export const ADMIN_CREDENTIALS = {
  username: 'admin',
  password: 'Zaq123..'
};